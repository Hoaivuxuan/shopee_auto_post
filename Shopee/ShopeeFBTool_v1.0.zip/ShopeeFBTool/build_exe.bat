@echo off
REM Dong goi thanh thu muc chay duoc tren may Windows khac (khong can cai Python).
REM Chay file nay tren may da cai Python 3.10+ va co Internet. Ket qua: dist\ShopeeFBTool\ShopeeFBTool.exe
REM Sau do chep CA THU MUC dist\ShopeeFBTool sang may khac (hoac nen zip) va chay ShopeeFBTool.exe.
cd /d "%~dp0"
echo === Cai thu vien ===
py -m pip install --upgrade pip
py -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto loi
echo === Dong goi (mat vai phut) ===
py -m PyInstaller --noconfirm --clean --windowed --name ShopeeFBTool --collect-all playwright --add-data "docs;docs" app.py
if errorlevel 1 goto loi
echo.
echo Xong! Mo thu muc dist\ShopeeFBTool va chay ShopeeFBTool.exe
echo May dich can co Microsoft Edge hoac Google Chrome (Windows 10/11 da co san Edge).
pause
exit /b 0
:loi
echo.
echo Co loi khi dong goi. Hay chup man hinh gui lai de duoc ho tro.
pause
exit /b 1
