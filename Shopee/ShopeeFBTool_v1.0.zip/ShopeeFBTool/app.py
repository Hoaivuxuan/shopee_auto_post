"""Điểm vào của chương trình.
  - Không có tham số: mở giao diện.
  - ShopeeFBTool.exe cli <lệnh> ...: chạy bằng dòng lệnh (xem tài liệu HUONG_DAN_COMMAND.md)."""
import os
import sys


def _fix_std_streams():
    # Bản đóng gói --windowed không có console: sys.stdout/sys.stderr có thể là None
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")


def _attach_console():
    """Khi chạy lệnh từ Command Prompt, gắn vào console đang mở để thấy kết quả (chỉ Windows)."""
    if os.name != "nt":
        return
    try:
        import ctypes
        if ctypes.windll.kernel32.AttachConsole(-1):
            sys.stdout = open("CONOUT$", "w", encoding="utf-8", buffering=1)
            sys.stderr = open("CONOUT$", "w", encoding="utf-8", buffering=1)
            sys.stdin = open("CONIN$", "r", encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass


def main():
    _fix_std_streams()
    if len(sys.argv) > 1 and sys.argv[1] in ("cli", "--cli"):
        _attach_console()
        from shopeetool.cli import main as cli_main
        sys.exit(cli_main(sys.argv[2:]))
    from shopeetool.gui import run
    run()


if __name__ == "__main__":
    main()
