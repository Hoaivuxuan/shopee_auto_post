"""Kiểm tra môi trường: trình duyệt, ffmpeg, thư mục dữ liệu, thư viện..."""
import os
import platform
import shutil
import sys

from . import VERSION, config as cfgmod
from .logger import mask
from .paths import app_dir, data_dir
from .shopee import find_ffmpeg, has_session


def browser_paths():
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    local = os.environ.get("LOCALAPPDATA", "")
    return {
        "msedge": [os.path.join(pf86, r"Microsoft\Edge\Application\msedge.exe"),
                   os.path.join(pf, r"Microsoft\Edge\Application\msedge.exe"),
                   shutil.which("microsoft-edge") or "", shutil.which("msedge") or ""],
        "chrome": [os.path.join(pf, r"Google\Chrome\Application\chrome.exe"),
                   os.path.join(pf86, r"Google\Chrome\Application\chrome.exe"),
                   os.path.join(local, r"Google\Chrome\Application\chrome.exe"),
                   shutil.which("google-chrome") or "", shutil.which("chrome") or ""],
    }


def detect_browsers():
    found = {}
    for name, paths in browser_paths().items():
        found[name] = next((p for p in paths if p and os.path.isfile(p)), None)
    return found


def check_all(cfg):
    """Trả về danh sách (mục, trạng thái 'ok'|'warn'|'error', chi tiết)."""
    out = []
    out.append(("Phiên bản chương trình", "ok", f"{VERSION} ({'đã đóng gói .exe' if getattr(sys, 'frozen', False) else 'chạy từ mã nguồn'})"))
    out.append(("Hệ điều hành", "ok" if os.name == "nt" else "warn",
                f"{platform.system()} {platform.release()}" + ("" if os.name == "nt" else " (chương trình được thiết kế cho Windows)")))
    try:
        import playwright  # noqa: F401
        out.append(("Thư viện Playwright", "ok", "Đã có"))
    except ImportError:
        out.append(("Thư viện Playwright", "error", "Chưa có (py -m pip install playwright). Bản .exe đã gồm sẵn."))
    br = detect_browsers()
    if br["msedge"] or br["chrome"]:
        names = [n for n, p in (("Microsoft Edge", br["msedge"]), ("Google Chrome", br["chrome"])) if p]
        out.append(("Trình duyệt để tải video", "ok", "Tìm thấy: " + ", ".join(names)))
    else:
        out.append(("Trình duyệt để tải video", "error", "Không thấy Microsoft Edge hoặc Google Chrome. Hãy cài một trong hai."))
    ff = find_ffmpeg()
    out.append(("ffmpeg (chỉ cần cho video dạng m3u8)", "ok" if ff else "warn",
                ff or "Chưa có. Video .mp4 vẫn tải bình thường. Cài bằng 'winget install ffmpeg' hoặc đặt ffmpeg.exe cạnh chương trình."))
    try:
        out.append(("Thư mục dữ liệu", "ok", data_dir()))
    except Exception as e:  # noqa: BLE001
        out.append(("Thư mục dữ liệu", "error", str(e)))
    out.append(("Thư mục chương trình", "ok", app_dir()))
    out.append(("Thư mục lưu video", "ok", cfgmod.videos_dir(cfg)))
    out.append(("Phiên đăng nhập Shopee", "ok" if has_session() else "warn",
                "Đã có" if has_session() else "Chưa có: vào Cấu hình > Shopee > 'Đăng nhập Shopee'"))
    s = cfg["sheet"]
    out.append(("Google Sheet", "ok" if (s["url"] and s["token"]) else "warn",
                "Đã nhập URL và token" if (s["url"] and s["token"]) else "Chưa cấu hình (Cấu hình > Google Sheet)"))
    n = len(cfg.get("pages", []))
    out.append(("Facebook Page", "ok" if n else "warn", f"{n} Page" if n else "Chưa có Page (Cấu hình > Facebook > 'Lấy Page')"))
    return out


def support_report(cfg):
    lines = [f"Shopee → Facebook Tool {VERSION}", ""]
    for name, st, detail in check_all(cfg):
        lines.append(f"[{st.upper():5}] {name}: {detail}")
    lines += ["", "Cấu hình (đã che thông tin bí mật):",
              f"  sheet.url   : {'đã nhập' if cfg['sheet']['url'] else 'trống'}",
              f"  sheet.token : {'đã nhập' if cfg['sheet']['token'] else 'trống'}",
              f"  facebook    : api {cfg['facebook']['api_version']}, hẹn giờ={cfg['facebook']['schedule_mode']}, "
              f"nghỉ {cfg['facebook']['min_delay']}-{cfg['facebook']['max_delay']}s",
              f"  pages       : {[p['name'] for p in cfg.get('pages', [])]}",
              f"  chế độ chạy : {cfg['run']['mode']}"]
    return mask("\n".join(lines))
