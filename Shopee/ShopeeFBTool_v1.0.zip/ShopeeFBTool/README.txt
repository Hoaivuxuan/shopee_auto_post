SHOPEE -> FACEBOOK TOOL
=======================
Tai video tu link san pham Shopee (trong Google Sheet) roi dang len nhieu Facebook Page,
ghi ket qua vao lai sheet. Giao dien tieng Viet, khong can go lenh.

CACH 1 - Dung ban .exe (khong can cai Python)
  1. Chep ca thu muc ShopeeFBTool (sau khi dong goi) sang may Windows 10/11.
  2. Bam dup ShopeeFBTool.exe.
  May can co Microsoft Edge (co san) hoac Google Chrome.

CACH 2 - Chay tu ma nguon (can Python 3.10+, tick "Add python.exe to PATH")
  Bam dup chay_ung_dung.bat (lan dau se tu cai thu vien).

TAO BAN .exe tu ma nguon
  Bam dup build_exe.bat (can Internet). Ket qua: dist\ShopeeFBTool\ShopeeFBTool.exe
  Chep CA THU MUC dist\ShopeeFBTool sang may khac de dung.

TAI LIEU (cung nam trong tab "Huong dan" cua chuong trinh)
  docs\HUONG_DAN_SU_DUNG.md   - Huong dan dung giao dien (doc cai nay truoc)
  docs\HUONG_DAN_KET_NOI.md   - Ket noi Google Sheet, Facebook Page, Shopee
  docs\HUONG_DAN_COMMAND.md   - Tong hop lenh (dong lenh)

DU LIEU (config, phien dang nhap Shopee, video, nhat ky) nam trong thu muc "data" canh chuong trinh.
Thu muc "data" CHUA TOKEN: khong gui cho ai.
